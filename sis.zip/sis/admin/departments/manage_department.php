<?php
require_once('../../config.php');
if(isset($_GET['id'])){
    $qry = $conn->query("SELECT * FROM `department_list` where id = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        $res = $qry->fetch_array();
        foreach($res as $k => $v){
            if(!is_numeric($k))
                $$k = $v;
        }
    }
}
?>

<!-- Google Fonts + Bootstrap 5 -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body {
        background: linear-gradient(145deg, #1a1a1a, #121212);
        font-family: 'Poppins', sans-serif;
        color: #fff;
    }

    .glass-dark-card {
        background: rgba(40, 40, 40, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-radius: 16px;
        padding: 25px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.6);
        color: #e0e0e0;
    }

    .glass-dark-card h4 {
        text-align: center;
        font-weight: 600;
        margin-bottom: 20px;
        background: linear-gradient(to right, #00f260, #0575e6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    label {
        font-weight: 500;
        color: #bdbdbd;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.05);
        border: none;
        border-radius: 10px;
        padding: 10px 14px;
        color: #fff;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        background: rgba(255, 255, 255, 0.1);
        outline: none;
        box-shadow: 0 0 0 2px #4facfe;
    }

    textarea.form-control {
        resize: none;
    }

    .form-select {
        background: rgba(255, 255, 255, 0.05);
        border: none;
        color: #fff;
        border-radius: 10px;
    }

    .form-select:focus {
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0 0 0 2px #43e97b;
    }

    .btn-glass {
        background: linear-gradient(to right, #43e97b, #38f9d7);
        border: none;
        color: #000;
        font-weight: 600;
        padding: 10px 25px;
        border-radius: 10px;
        margin-top: 15px;
        transition: 0.3s ease;
    }

    .btn-glass:hover {
        background: linear-gradient(to right, #38f9d7, #43e97b);
        box-shadow: 0 0 15px #38f9d7;
        transform: translateY(-2px);
    }

</style>

<div class="container my-4">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="glass-dark-card">
                <h4><?= isset($id) ? "Edit Department" : "New Department" ?></h4>
                <form action="" id="department-form">
                    <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Department Name</label>
                        <input type="text" name="name" id="name" class="form-control"
                               placeholder="Enter Department Name"
                               value="<?= isset($name) ? $name : '' ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea rows="3" name="description" id="description"
                                  class="form-control" required><?= isset($description) ? $description : '' ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-select" required>
                            <option value="1" <?= isset($status) && $status == 1 ? 'selected' : '' ?>>Active</option>
                            <option value="0" <?= isset($status) && $status == 0 ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-glass">Save Department</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(function(){
        $('#uni_modal #department-form').submit(function(e){
            e.preventDefault();
            var _this = $(this);
            $('.pop-msg').remove();
            var el = $('<div>').addClass("pop-msg alert").hide();
            start_loader();
            $.ajax({
                url: _base_url_ + "classes/Master.php?f=save_department",
                data: new FormData(_this[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
                error: err => {
                    console.log(err);
                    alert_toast("An error occurred", 'error');
                    end_loader();
                },
                success: function(resp){
                    if(resp.status === 'success'){
                        location.reload();
                    } else {
                        el.addClass("alert-danger").text(resp.msg || "An unknown error occurred.");
                        _this.prepend(el);
                        el.show('slow');
                        end_loader();
                    }
                }
            });
        });
    });
</script>
