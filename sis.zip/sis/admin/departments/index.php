<style>
    body {
        background: url('https://images.unsplash.com/photo-1596495577886-d920f1fb7238') no-repeat center center fixed;
        background-size: cover;
        backdrop-filter: blur(6px);
    }

    .card.card-outline {
        background: rgba(44, 43, 43, 0.9);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 1.25rem;
        box-shadow: 0 10px 40px rgba(148, 28, 28, 0.69);
        color: #fff;
        overflow: hidden;
    }

    .card-header {
        background: linear-gradient(to right, #1f1c2c,rgb(52, 32, 152));
        padding: 1.5rem 2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .card-title {
        font-size: 1.9rem;
        font-weight: 700;
        color: #1de9b6;
        text-shadow: 0 1px 3px rgba(0,0,0,0.5);
    }

    .card-tools .btn {
        border-radius: 10px;
        font-weight: bold;
        padding: 0.5rem 1rem;
        background: linear-gradient(135deg, #1de9b6, #1dc4e9);
        color:rgb(49, 50, 50);
        border: none;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
        transition: 0.3s;
    }

    .card-tools .btn:hover {
        transform: translateY(-2px);
        opacity: 0.9;
    }

    .table {
        margin-top: 1rem;
        background: rgba(83, 151, 224, 0.61);
        color: #fff;
        border-radius: 1rem;
        overflow: hidden;
    }

    .table thead tr {
        background: rgba(104, 65, 65, 0.75);
        color: #1de9b6;
        font-size: 1rem;
    }

    .table tbody tr {
        background: rgba(255, 255, 255, 0.02);
    }

    .table td, .table th {
        padding: 1rem;
        vertical-align: middle;
    }

    .badge {
        font-size: 0.85rem;
        padding: 0.4em 0.75em;
        border-radius: 1rem;
    }

    .bg-gradient-teal {
        background: linear-gradient(45deg, #1de9b6, #1dc4e9);
        color: white;
    }

    .bg-gradient-danger {
        background: linear-gradient(45deg, #e53935, #f44336);
        color: white;
    }

    .dropdown-menu {
        background-color:rgb(83, 128, 174);
        border-radius: 0.75rem;
        box-shadow: 0 10px 20px rgba(26, 214, 148, 0.7);
    }

    .dropdown-menu a {
        color: ; #1de9b6
        padding: 0.75rem 1.25rem;
        font-weight: 500;
    }

    .dropdown-menu a:hover {
        background: rgba(126, 56, 56, 0.08);
    }
</style>



<div class="card card-outline card-primary shadow mt-4">
    <div class="card-header">
        <h3 class="card-title">📚 List of Departments</h3>
        <?php if($_settings->userdata('type') == 1): ?>
        <div class="card-tools">
            <a href="javascript:void(0)" id="create_new" class="btn btn-sm btn-primary"><i class="fas fa-plus"></i> Add Department</a>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-bordered table-hover table-striped">
                <colgroup>
                    <col width="5%">
                    <col width="15%">
                    <col width="25%">
                    <col width="25%">
                    <col width="15%">
                    <col width="15%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date Created</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $i = 1;
                        $qry = $conn->query("SELECT * FROM `department_list` WHERE delete_flag = 0 ORDER BY `name` ASC ");
                        while($row = $qry->fetch_assoc()):
                    ?>
                    <tr>
                        <td class="text-center"><?= $i++; ?></td>
                        <td><?= date("Y-m-d H:i", strtotime($row['date_created'])) ?></td>
                        <td><?= $row['name'] ?></td>
                        <td><?= $row['description'] ?></td>
                        <td class="text-center">
                            <?= $row['status'] == 1 
                                ? '<span class="badge bg-gradient-teal">Active</span>' 
                                : '<span class="badge bg-gradient-danger">Inactive</span>'; ?>
                        </td>
                        <td class="text-end position-relative">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light dropdown-toggle" type="button" id="actionDropdown<?= $row['id'] ?>" data-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actionDropdown<?= $row['id'] ?>">
                                    <a class="dropdown-item view_data" href="javascript:void(0)" data-id="<?= $row['id'] ?>"><i class="fa fa-eye text-info"></i> View</a>
                                    <?php if($_settings->userdata('type') == 1): ?>
                                    <a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?= $row['id'] ?>"><i class="fa fa-edit text-primary"></i> Edit</a>
                                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?= $row['id'] ?>"><i class="fa fa-trash text-danger"></i> Delete</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#create_new').click(function(){
        uni_modal("Add New Department", "departments/manage_department.php")
    })
    $('.view_data').click(function(){
        uni_modal("Department Details", "departments/view_department.php?id=" + $(this).data('id'))
    })
    $('.edit_data').click(function(){
        uni_modal("Update Department", "departments/manage_department.php?id=" + $(this).data('id'))
    })
    $('.delete_data').click(function(){
        _conf("Are you sure you want to delete this department?", "delete_department", [$(this).data('id')])
    })

    $('.table').dataTable({
        columnDefs: [
            { orderable: false, targets: 5 }
        ],
    });
})

function delete_department(id){
    start_loader();
    $.ajax({
        url: _base_url_ + "classes/Master.php?f=delete_department",
        method: "POST",
        data: { id: id },
        dataType: "json",
        error: err => {
            console.log(err)
            alert_toast("An error occurred.", 'error');
            end_loader();
        },
        success: function(resp){
            if(resp.status == 'success'){
                location.reload();
            } else {
                alert_toast("An error occurred.", 'error');
                end_loader();
            }
        }
    })
}
</script>
