<style>
  /* Sidebar Glassmorphism */
  .main-sidebar {
    background: rgba(30, 30, 30, 0.8) !important;
    backdrop-filter: blur(12px);
    border-right: 1px solid rgba(255, 255, 255, 0.05);
    box-shadow: 4px 0 10px rgba(0, 0, 0, 0.3);
  }

  .brand-link {
    backdrop-filter: blur(10px);
    color: #ffffff !important;
    font-weight: bold;
    font-size: 1.05rem;
    padding: 0.75rem 1rem;
    display: flex;
    align-items: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  }

  .brand-link:hover {
    background-color: rgba(255, 255, 255, 0.05);
  }

  .brand-link .brand-image {
    margin-right: 10px;
    box-shadow: 0 0 8px rgba(0, 255, 255, 0.5);
    border: 2px solid rgba(255, 255, 255, 0.1);
  }

  .nav-sidebar > .nav-item > .nav-link {
    color: #dcdcdc;
    transition: all 0.3s ease;
    border-radius: 6px;
    margin-bottom: 2px;
  }

  .nav-sidebar > .nav-item > .nav-link:hover {
    background-color: rgba(0, 255, 255, 0.1);
    color: #00ffff;
    box-shadow: inset 0 0 5px rgba(0, 255, 255, 0.2);
  }

  .nav-sidebar .nav-icon {
    color: #00ffff !important;
    font-size: 1rem;
  }

  .nav-sidebar .nav-header {
    font-weight: bold;
    color: #00ffff;
    font-size: 0.85rem;
    margin-top: 1rem;
    text-transform: uppercase;
  }

  .nav-sidebar .active {
    background-color: rgba(0, 255, 255, 0.2) !important;
    color: #ffffff !important;
    box-shadow: 0 0 10px rgba(0, 255, 255, 0.3) inset;
  }

  .nav-sidebar .active .nav-icon {
    color: #ffffff !important;
  }

  .os-scrollbar-track {
    background: transparent !important;
  }
</style>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4 sidebar-no-expand">
  <!-- Brand Logo -->
  <a href="<?php echo base_url ?>admin" class="brand-link bg-transparent">
    <img src="<?php echo validate_image($_settings->info('logo')) ?>" alt="Store Logo"
      class="brand-image img-circle elevation-3 bg-black"
      style="width: 1.8rem;height: 1.8rem;object-fit:scale-down;object-position:center;">
    <span class="brand-text font-weight-light"><?php echo $_settings->info('short_name') ?></span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar Menu -->
    <nav class="mt-3">
      <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-flat nav-child-indent nav-collapse-hide-child"
        data-widget="treeview" role="menu" data-accordion="false">
        
        <li class="nav-item">
          <a href="./" class="nav-link nav-home">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <li class="nav-header">Students</li>

        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=students/manage_student" class="nav-link nav-students_manage_student">
            <i class="nav-icon fas fa-plus"></i>
            <p>New Student</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=students" class="nav-link nav-students">
            <i class="nav-icon fas fa-user-friends"></i>
            <p>Student List</p>
          </a>
        </li>

        <li class="nav-header">Maintenance</li>

        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=departments" class="nav-link nav-departments">
            <i class="nav-icon fas fa-building"></i>
            <p>Department List</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=courses" class="nav-link nav-courses">
            <i class="nav-icon fas fa-scroll"></i>
            <p>Course List</p>
          </a>
        </li>

        <?php if($_settings->userdata('type') == 1): ?>
        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=user/list" class="nav-link nav-user_list">
            <i class="nav-icon fas fa-users-cog"></i>
            <p>User List</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url ?>admin/?page=system_info" class="nav-link nav-system_info">
            <i class="nav-icon fas fa-cogs"></i>
            <p>Settings</p>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>

<script>
  var page;
  $(document).ready(function () {
    page = '<?php echo isset($_GET['page']) ? $_GET['page'] : 'home' ?>';
    page = page.replace(/\//gi, '_');

    if ($('.nav-link.nav-' + page).length > 0) {
      $('.nav-link.nav-' + page).addClass('active')
      if ($('.nav-link.nav-' + page).hasClass('tree-item')) {
        $('.nav-link.nav-' + page).closest('.nav-treeview').siblings('a').addClass('active')
        $('.nav-link.nav-' + page).closest('.nav-treeview').parent().addClass('menu-open')
      }
      if ($('.nav-link.nav-' + page).hasClass('nav-is-tree')) {
        $('.nav-link.nav-' + page).parent().addClass('menu-open')
      }
    }

    $('#receive-nav').click(function () {
      $('#uni_modal').on('shown.bs.modal', function () {
        $('#find-student [name="tracking_code"]').focus();
      })
      uni_modal("Enter Tracking Number", "student/find_student.php");
    })
  })
</script>
