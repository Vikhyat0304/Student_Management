<style>
  .main-header {
    background: rgba(0, 0, 0, 0.7) !important;
    backdrop-filter: blur(12px);
    box-shadow: 0 8px 15px rgba(0, 255, 255, 0.1);
    border-bottom: 1px solid rgba(0, 255, 255, 0.2);
    transition: background 0.3s ease;
  }

  .navbar-nav .nav-link {
    color: #ffffff !important;
    font-weight: 500;
    transition: all 0.3s ease;
    position: relative;
  }

  .navbar-nav .nav-link:hover {
    color: #00ffff !important;
    text-shadow: 0 0 6px rgba(0, 255, 255, 0.5);
  }

  .navbar-nav .nav-link::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    height: 2px;
    width: 0;
    background: #00ffff;
    transition: 0.3s ease;
  }

  .navbar-nav .nav-link:hover::after {
    width: 100%;
  }

  .navbar-nav .dropdown-menu {
    background: rgba(20, 20, 20, 0.95);
    border-radius: 12px;
    padding: 0.5rem;
    min-width: 200px;
    border: none;
    box-shadow: 0 8px 20px rgba(0, 255, 255, 0.15);
  }

  .navbar-nav .dropdown-item {
    color: #f0f0f0;
    padding: 8px 14px;
    font-weight: 500;
    border-radius: 6px;
    transition: all 0.2s ease;
  }

  .navbar-nav .dropdown-item:hover {
    background: rgba(255, 255, 255, 0.08);
    color: #00ffff;
  }

  .user-img {
    height: 34px;
    width: 34px;
    object-fit: cover;
    border-radius: 50%;
    margin-right: 8px;
    box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
    border: 2px solid rgba(0, 255, 255, 0.3);
  }

  .btn-rounded {
    border-radius: 30px;
    background: rgba(255, 255, 255, 0.05);
    color: #fff;
    padding: 6px 14px;
    transition: all 0.3s ease;
  }

  .btn-rounded:hover {
    background-color: rgba(0, 255, 255, 0.1);
    color: #00ffff;
  }

  .navbar-nav .nav-item b {
    font-size: 1rem;
    color: #ffffff;
  }
</style>

<!-- Dark Glass Navbar -->
<nav class="main-header navbar navbar-expand navbar-light text-sm shadow-sm">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="<?php echo base_url ?>" class="nav-link">
        <b><?php echo (!isMobileDevice()) ? $_settings->info('name') : $_settings->info('short_name'); ?> - Admin</b>
      </a>
    </li>
  </ul>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <!-- User Dropdown -->
    <li class="nav-item">
      <div class="btn-group nav-link">
        <button type="button" class="btn btn-rounded dropdown-toggle dropdown-icon" data-toggle="dropdown">
          <img src="<?php echo validate_image($_settings->userdata('avatar')) ?>" alt="User Image" class="user-img">
          <span><?php echo ucwords($_settings->userdata('firstname') . ' ' . $_settings->userdata('lastname')) ?></span>
        </button>
        <div class="dropdown-menu dropdown-menu-right" role="menu">
          <a class="dropdown-item" href="<?php echo base_url . 'admin/?page=user' ?>">
            <span class="fa fa-user mr-2"></span> My Account
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo base_url . '/classes/Login.php?f=logout' ?>">
            <span class="fas fa-sign-out-alt mr-2"></span> Logout
          </a>
        </div>
      </div>
    </li>
  </ul>
</nav>
