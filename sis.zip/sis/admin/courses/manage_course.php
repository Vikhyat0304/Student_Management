<?php
require_once('../../config.php');
if (isset($_GET['id'])) {
    $qry = $conn->query("SELECT * FROM `course_list` where id = '{$_GET['id']}'");
    if ($qry->num_rows > 0) {
        $res = $qry->fetch_array();
        foreach ($res as $k => $v) {
            if (!is_numeric($k)) $$k = $v;
        }
    }
}
?>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

  .modal-body {
    font-family: 'Inter', sans-serif;
    background: rgba(17, 24, 39, 0.95);
    padding: 2.8rem;
    border-radius: 18px;
    box-shadow: 0 25px 55px rgba(0, 0, 0, 0.9);
    border: 1px solid rgba(255, 255, 255, 0.07);
    backdrop-filter: blur(12px);
    color: #f1f5f9;
    position: relative;
  }

  .form-group {
    margin-bottom: 1.8rem;
  }

  .form-group label {
    font-weight: 600;
    color: #cbd5e1;
    display: block;
    margin-bottom: 0.5rem;
  }

  .form-control,
  .form-control-sm,
  .form-control-border {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 12px;
    padding: 14px 16px;
    color: #ffffff;
    font-size: 0.95rem;
    transition: 0.3s ease;
  }

  .form-control:focus,
  .form-control-sm:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
    background: rgba(255, 255, 255, 0.08);
  }

  textarea.form-control-sm {
    resize: none;
    min-height: 100px;
  }

  select.form-control-sm option {
    background: #0f172a;
    color: #fff;
  }

  .btn-submit {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    color: white;
    padding: 12px 28px;
    border: none;
    border-radius: 30px;
    font-weight: 600;
    font-size: 1rem;
    margin-top: 1.2rem;
    cursor: pointer;
    transition: all 0.3s ease;
  }

  .btn-submit:hover {
    background: linear-gradient(135deg, #6366f1, #3b82f6);
    box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
  }
</style>

<div class="modal-body">
  <form action="" id="course-form">
    <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">

    <div class="form-group">
      <label for="department_id">Department</label>
      <select name="department_id" id="department_id" class="form-control form-control-sm form-control-border" required>
        <option value="" disabled <?= !isset($department_id) ? "selected" : "" ?>></option>
        <?php 
          $departments = $conn->query("SELECT * FROM `department_list` WHERE delete_flag = 0 AND `status` = 1 " . (isset($department_id) ? " OR id = '{$department_id}'" : "") . " ORDER BY `name` ASC");
          while ($row = $departments->fetch_assoc()):
        ?>
          <option value="<?= $row['id'] ?>" <?= isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>>
            <?= $row['name'] ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <div class="form-group">
      <label for="name">Course Name</label>
      <input type="text" name="name" id="name" class="form-control form-control-border" placeholder="Enter course name" value="<?php echo isset($name) ? $name : '' ?>" required>
    </div>

    <div class="form-group">
      <label for="description">Description</label>
      <textarea name="description" id="description" class="form-control form-control-sm" required><?php echo isset($description) ? $description : '' ?></textarea>
    </div>

    <div class="form-group">
      <label for="status">Status</label>
      <select name="status" id="status" class="form-control form-control-sm form-control-border" required>
        <option value="1" <?= isset($status) && $status == 1 ? 'selected' : '' ?>>Active</option>
        <option value="0" <?= isset($status) && $status == 0 ? 'selected' : '' ?>>Inactive</option>
      </select>
    </div>

    <button type="submit" class="btn-submit">Save Course</button>
  </form>
</div>

<script>
  $(function () {
    $('#uni_modal').on('shown.bs.modal', function () {
      $('#department_id').select2({
        placeholder: 'Please Select Here',
        width: '100%',
        dropdownParent: $('#uni_modal')
      });
    });

    $('#uni_modal #course-form').submit(function (e) {
      e.preventDefault();
      var _this = $(this);
      $('.pop-msg').remove();
      var el = $('<div>').addClass("pop-msg alert").hide();
      start_loader();

      $.ajax({
        url: _base_url_ + "classes/Master.php?f=save_course",
        data: new FormData(this),
        cache: false,
        contentType: false,
        processData: false,
        method: 'POST',
        dataType: 'json',
        error: err => {
          console.log(err);
          alert_toast("An error occurred", 'error');
          end_loader();
        },
        success: function (resp) {
          if (resp.status === 'success') {
            location.reload();
          } else {
            el.addClass("alert-danger").text(resp.msg || "Unknown error occurred.");
            _this.prepend(el);
            el.show('slow');
            $('html, body, .modal').animate({ scrollTop: 0 }, 'fast');
          }
          end_loader();
        }
      });
    });
  });
</script>
