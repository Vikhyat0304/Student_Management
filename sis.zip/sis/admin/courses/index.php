<style>
  body {
    background: #f0f2f5;
    font-family: 'Inter', sans-serif;
  }

  .container-course-list {
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 15px;
  }

  .header-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
  }

  .header-bar h3 {
    font-weight: 700;
    font-size: 1.8rem;
    color: #222;
  }

  #courseSearch {
    padding: 8px 14px;
    border-radius: 50px;
    border: 1.5px solid #ddd;
    width: 280px;
    transition: border-color 0.3s ease;
  }

  #courseSearch:focus {
    outline: none;
    border-color: #2575fc;
    box-shadow: 0 0 8px rgba(37, 117, 252, 0.5);
  }

  #create_new {
    background: #2575fc;
    border: none;
    color: white;
    padding: 10px 22px;
    font-weight: 600;
    border-radius: 30px;
    cursor: pointer;
    box-shadow: 0 6px 12px rgba(37,117,252,0.4);
    transition: background 0.3s ease;
  }

  #create_new:hover {
    background: #6a11cb;
    box-shadow: 0 6px 20px rgba(106,17,203,0.6);
  }

  .course-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill,minmax(300px,1fr));
    gap: 20px;
  }

  .course-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    padding: 20px;
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
  }

  .course-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
  }

  .course-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: #2575fc;
    margin-bottom: 6px;
  }

  .course-department {
    font-size: 0.9rem;
    font-weight: 600;
    color: #555;
    margin-bottom: 12px;
  }

  .course-description {
    flex-grow: 1;
    font-size: 0.95rem;
    color: #666;
    margin-bottom: 16px;
    max-height: 72px;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .course-date {
    font-size: 0.85rem;
    color: #999;
    margin-bottom: 12px;
  }

  .badge-status {
    padding: 5px 14px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.85rem;
    color: white;
    display: inline-block;
  }

  .badge-active {
    background-color: #2ecc71;
  }

  .badge-inactive {
    background-color: #e74c3c;
  }

  .dropdown {
    position: absolute;
    top: 20px;
    right: 20px;
  }

  .dropdown-toggle {
    background: #2575fc;
    border: none;
    color: white;
    padding: 6px 14px;
    border-radius: 50px;
    cursor: pointer;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(37,117,252,0.4);
    transition: background 0.3s ease;
  }

  .dropdown-toggle:hover {
    background: #6a11cb;
    box-shadow: 0 4px 18px rgba(106,17,203,0.6);
  }

  .dropdown-menu {
    margin-top: 6px;
    border-radius: 12px;
    box-shadow: 0 12px 30px rgba(0,0,0,0.15);
    padding: 8px 0;
    min-width: 140px;
  }

  .dropdown-item {
    padding: 8px 18px;
    font-weight: 600;
    color: #444;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .dropdown-item:hover {
    background: #f0f2f5;
    color: #2575fc;
  }

  .dropdown-item i {
    font-size: 1rem;
  }

  /* Responsive tweak for small screens */
  @media (max-width: 450px) {
    .course-grid {
      grid-template-columns: 1fr;
    }

    #courseSearch {
      width: 100%;
      margin-bottom: 10px;
    }

    .header-bar {
      flex-direction: column;
      align-items: stretch;
      gap: 12px;
    }
  }
</style>

<div class="container-course-list">
  <div class="header-bar">
    <h3>Courses List</h3>
    <div class="d-flex align-items-center gap-3">
      <input type="search" id="courseSearch" placeholder="Search courses...">
      <?php if($_settings->userdata('type') == 1): ?>
        <button id="create_new">+ Add New Course</button>
      <?php endif; ?>
    </div>
  </div>

  <div class="course-grid" id="coursesGrid">
    <?php 
      $qry = $conn->query("SELECT c.*, d.name as department FROM `course_list` c INNER JOIN department_list d ON c.department_id = d.id WHERE c.delete_flag = 0 ORDER BY c.`name` ASC");
      while($row = $qry->fetch_assoc()):
    ?>
    <div class="course-card" data-search="<?php echo strtolower(htmlspecialchars($row['name'] . ' ' . $row['department'] . ' ' . $row['description'])); ?>">
      <div class="course-title"><?php echo htmlspecialchars($row['name']); ?></div>
      <div class="course-department"><?php echo htmlspecialchars($row['department']); ?></div>
      <div class="course-description" title="<?php echo htmlspecialchars($row['description']); ?>">
        <?php echo htmlspecialchars($row['description']); ?>
      </div>
      <div class="course-date">Created: <?php echo date("Y-m-d", strtotime($row['date_created'])); ?></div>
      <div>
        <?php if($row['status'] == 1): ?>
          <span class="badge-status badge-active">Active</span>
        <?php else: ?>
          <span class="badge-status badge-inactive">Inactive</span>
        <?php endif; ?>
      </div>
      <div class="dropdown">
        <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          Action
        </button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item view_data" href="javascript:void(0)" data-id="<?php echo $row['id']; ?>"><i class="fas fa-eye"></i> View</a></li>
          <?php if($_settings->userdata('type') == 1): ?>
          <li><a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> Edit</a></li>
          <li><a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id']; ?>"><i class="fas fa-trash"></i> Delete</a></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>

<script>
  $(document).ready(function(){
    $('#create_new').click(function(){
      uni_modal("Add New Course", "courses/manage_course.php");
    });

    $('.view_data').click(function(){
      uni_modal("Course Details", "courses/view_course.php?id=" + $(this).attr('data-id'));
    });

    $('.edit_data').click(function(){
      uni_modal("Update Course Details", "courses/manage_course.php?id=" + $(this).attr('data-id'));
    });

    $('.delete_data').click(function(){
      _conf("Are you sure to delete this Course permanently?", "delete_course", [$(this).attr('data-id')]);
    });

    // Bootstrap dropdown init
    var dropdownElements = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
    dropdownElements.map(function(el) {
      return new bootstrap.Dropdown(el);
    });

    // Search filter on cards
    $('#courseSearch').on('input', function(){
      var val = $(this).val().toLowerCase();
      $('.course-card').each(function(){
        var searchable = $(this).data('search');
        $(this).toggle(searchable.includes(val));
      });
    });
  });

  function delete_course(id){
    start_loader();
    $.ajax({
      url: _base_url_ + "classes/Master.php?f=delete_course",
      method: "POST",
      data: {id: id},
      dataType: "json",
      error: err => {
        console.error(err);
        alert_toast("An error occurred.", 'error');
        end_loader();
      },
      success: function(resp){
        if(resp.status == 'success'){
          location.reload();
        } else {
          alert_toast("An error occurred.", 'error');
          end_loader();
        }
      }
    });
  }
</script>
