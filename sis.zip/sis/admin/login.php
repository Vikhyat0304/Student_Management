<?php require_once('../config.php') ?>
<!DOCTYPE html>
<html lang="en">
<?php require_once('inc/header.php') ?>
<head>
  <meta charset="UTF-8">
  <title>Login - Hostel Warden</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    * {
      font-family: 'Poppins', sans-serif;
    }

    body, html {
      height: 100%;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: url('https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1920&q=80') no-repeat center center fixed;
      background-size: cover;
    }

    .login-glass {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 50px 35px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 12px 40px rgba(0,0,0,0.3);
      color: #fff;
      border: 1px solid rgba(255, 255, 255, 0.18);
      transition: all 0.3s ease;
    }

    .login-glass:hover {
      transform: scale(1.02);
      box-shadow: 0 14px 50px rgba(0,0,0,0.35);
    }

    .login-glass input {
      background: rgba(255, 255, 255, 0.15);
      border: none;
      color: #fff;
    }

    .login-glass input::placeholder {
      color: #ccc;
    }

    .login-glass .form-control:focus {
      box-shadow: none;
      border-color: #fff;
    }

    .login-glass .btn {
      background-color: #00bcd4;
      border: none;
      font-weight: 600;
    }

    .login-glass .btn:hover {
      background-color: #0097a7;
    }

    .logo-img {
      width: 90px;
      height: 90px;
      object-fit: cover;
      border-radius: 50%;
      box-shadow: 0 0 12px rgba(255,255,255,0.3);
      margin-bottom: 20px;
    }

    .title {
      font-weight: 600;
      text-shadow: 1px 1px 3px #000;
    }
  </style>
</head>

<body>
  <div class="login-glass text-center">
    <img src="<?= validate_image($_settings->info('logo')) ?>" alt="Logo" class="logo-img">
    <h3 class="mb-4 title"><?php echo $_settings->info('name') ?><br><small class="text-white-50">Warden Login</small></h3>

    <form id="login-frm" method="post">
      <div class="mb-3">
        <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" name="password" placeholder="Password" required>
      </div>
      <button type="submit" class="btn btn-info w-100">Sign In</button>
    </form>
  </div>

  <!-- Scripts -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function(){
      end_loader();
    });
  </script>
</body>
</html>
