<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif; ?>

<style>
    body {
        background-color: #0f172a;
    }

    .glass-card {
        background: rgba(30, 41, 59, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 20px;
        backdrop-filter: blur(12px);
        box-shadow: 0 12px 60px rgba(0, 0, 0, 0.7);
        padding: 2.5rem;
        color: #e2e8f0;
        font-family: 'Inter', sans-serif;
        transition: 0.3s ease-in-out;
    }

    .glass-card:hover {
        box-shadow: 0 18px 80px rgba(0, 0, 0, 0.9);
        transform: translateY(-6px);
    }

    label {
        font-weight: 600;
        font-size: 1rem;
        color: #cbd5e1;
        margin-bottom: 0.3rem;
    }

    .form-control,
    .custom-file-input {
        background: #1e293b;
        border: 1px solid #334155;
        color: #f1f5f9;
        border-radius: 12px;
        padding: 12px 16px;
        transition: 0.3s;
    }

    .form-control:focus,
    .custom-file-input:focus {
        background: #273549;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
        border-color: #3b82f6;
        color: #fff;
    }

    .custom-file-label {
        background-color: #1f2937;
        border: 1px solid #334155;
        color: #e5e7eb;
    }

    .custom-file-input:hover + .custom-file-label {
        background-color: #374151;
        color: #fff;
    }

    .btn-primary {
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        border: none;
        border-radius: 10px;
        padding: 8px 20px;
    }

    .btn-primary:hover {
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
    }

    #cimg, #cimg2 {
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6);
        object-fit: contain;
    }

    #cimg {
        height: 15vh;
        width: 15vh;
    }

    #cimg2 {
        height: 50vh;
        width: 100%;
    }
</style>

<div class="col-lg-12">
    <div class="glass-card">
        <h4 class="mb-4">System Information</h4>
        <form action="" id="system-frm">
            <div id="msg" class="form-group"></div>
            <div class="form-group">
                <label for="name">System Name</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo $_settings->info('name') ?>">
            </div>
            <div class="form-group">
                <label for="short_name">System Short Name</label>
                <input type="text" class="form-control" name="short_name" id="short_name" value="<?php echo $_settings->info('short_name') ?>">
            </div>
            <div class="form-group">
                <label for="logo">System Logo</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFile" name="img" onchange="displayImg(this,$(this))">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                </div>
            </div>
            <div class="form-group d-flex justify-content-center">
                <img src="<?php echo validate_image($_settings->info('logo')) ?>" alt="Logo" id="cimg" class="img-fluid img-thumbnail">
            </div>
            <div class="form-group">
                <label for="cover">System Cover</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFile2" name="cover" onchange="displayImg2(this,$(this))">
                    <label class="custom-file-label" for="customFile2">Choose file</label>
                </div>
            </div>
            <div class="form-group d-flex justify-content-center">
                <img src="<?php echo validate_image($_settings->info('cover')) ?>" alt="Cover" id="cimg2" class="img-fluid img-thumbnail">
            </div>
            <div class="text-center mt-4">
                <button class="btn btn-primary" form="system-frm">Update</button>
            </div>
        </form>
    </div>
</div>

<script>
    function displayImg(input, _this) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#cimg').attr('src', e.target.result);
                _this.siblings('.custom-file-label').html(input.files[0].name);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    function displayImg2(input, _this) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#cimg2').attr('src', e.target.result);
                _this.siblings('.custom-file-label').html(input.files[0].name);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $(document).ready(function() {
        $('.custom-file-input').on('change', function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    });
</script>
