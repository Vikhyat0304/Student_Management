<h1 class="dashboard-title" data-aos="fade-down">Welcome to <?php echo $_settings->info('name') ?> - Admin Panel</h1>
<hr class="border-purple">

<!-- AOS CSS & JS -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000 });
</script>

<style>
  body {

background: linear-gradient(to right, #1f1c2c,rgb(33, 25, 73)); /* Purple Gradient */
  color:rgb(166, 49, 49);
  font-family: 'Inter', sans-serif;

  }

  .dashboard-title {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 30px;
    color:rgb(137, 48, 48);
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.6);
  }

  .info-box {
    border-radius: 16px;
    background: rgba(138, 33, 33, 0.4);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease;
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  .info-box:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4);
  }

  .info-box-icon {
    border-radius: 12px;
    font-size: 1.8rem;
    color: #fff;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 12px;
    background: rgba(255, 255, 255, 0.1);
  }

  .info-box-text {
    font-size: 1rem;
    font-weight: 600;
    color:rgb(104, 31, 31);
  }

  .info-box-number {
    font-size: 1.5rem;
    font-weight: 700;
    color:rgb(107, 38, 38);
  }

  #website-cover {
    width: 100%;
    height: 360px;
    object-fit: cover;
    object-position: center center;
    border-radius: 20px;
    margin-top: 25px;
    box-shadow: 0 12px 25px rgba(0, 0, 0, 0.35);
    border: 4px solid rgba(72, 119, 28, 0.37);
  }

  hr.border-purple {
    border: none;
    height: 3px;
    background: linear-gradient(to right, #ff00cc, #333399);
    margin-bottom: 2rem;
    border-radius: 10px;
  }
</style>

<div class="row">
  <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up">
    <div class="info-box">
      <span class="info-box-icon"><i class="fas fa-building"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Total Departments</span>
        <span class="info-box-number text-right">
          <?php echo $conn->query("SELECT * FROM `department_list` WHERE delete_flag=0 AND status=1")->num_rows; ?>
        </span>
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="100">
    <div class="info-box">
      <span class="info-box-icon"><i class="fas fa-scroll"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Total Courses</span>
        <span class="info-box-number text-right">
          <?php echo $conn->query("SELECT * FROM `course_list` WHERE delete_flag=0 AND status=1")->num_rows; ?>
        </span>
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="200">
    <div class="info-box">
      <span class="info-box-icon"><i class="fas fa-user-friends"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Students</span>
        <span class="info-box-number text-right">
          <?php echo $conn->query("SELECT * FROM `student_list`")->num_rows; ?>
        </span>
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="300">
    <div class="info-box">
      <span class="info-box-icon"><i class="fas fa-file-alt"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Student Academics</span>
        <span class="info-box-number text-right">
          <?php echo $conn->query("SELECT * FROM `academic_history`")->num_rows; ?>
        </span>
      </div>
    </div>
  </div>
</div>

<div class="row" data-aos="zoom-in" data-aos-delay="400">
  <div class="col-md-12">
    <img src="https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1500&q=80" 
         alt="Website Cover" class="img-fluid" id="website-cover">
  </div>
</div>
