<?php if ($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>", 'success');
</script>
<?php endif; ?>

<style>
  body {
    background: #0f172a;
    font-family: 'Inter', sans-serif;
  }

  .custom-user-card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 20px;
    padding: 25px;
    backdrop-filter: blur(10px);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
    color:rgba(62, 155, 189, 0.86);
    animation: fadeIn 0.5s ease-in-out;
    margin-top: 30px;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .custom-user-card h3 {
    font-weight: 700;
    font-size: 1.6rem;
    color:rgb(156, 58, 58);
  }

  .custom-user-card .btn-primary {
    background: linear-gradient(to right, #3b82f6, #6366f1);
    border: none;
    border-radius: 25px;
    padding: 8px 20px;
    font-weight: 600;
    box-shadow: 0 4px 14px rgba(99, 102, 241, 0.5);
  }

  .custom-user-card .btn-primary:hover {
    background: linear-gradient(to right, #6366f1, #3b82f6);
  }

  .img-avatar {
    width: 45px;
    height: 45px;
    object-fit: cover;
    object-position: center;
    border-radius: 50%;
    border: 2px solid #94a3b8;
  }

  table.custom-table {
    width: 100%;
    margin-top: 20px;
    border-collapse: separate;
    border-spacing: 0 10px;
  }

  .custom-table thead th {
    color:rgb(34, 64, 107);
    font-weight: 600;
    font-size: 0.95rem;
    padding: 10px 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }

  .custom-table tbody tr {
    background: rgba(255, 255, 255, 0.03);
    transition: 0.3s ease;
    border-radius: 12px;
  }

  .custom-table tbody tr:hover {
    background: rgba(255, 255, 255, 0.07);
  }

  .custom-table td {
    padding: 12px 15px;
    vertical-align: middle;
    color:rgb(53, 104, 171);
  }

  .dropdown-menu {
    background: #1e293b;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0,0,0,0.3);
    padding: 0;
    overflow: hidden;
  }

  .dropdown-item {
    color: #cbd5e1;
    font-weight: 500;
    padding: 10px 16px;
  }

  .dropdown-item:hover {
    background: #3b82f6;
    color: #fff;
  }
</style>

<div class="custom-user-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>System Users</h3>
    <a href="?page=user/manage_user" class="btn btn-primary"><i class="fas fa-plus"></i> Create New</a>
  </div>

  <div class="table-responsive">
    <table class="custom-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Avatar</th>
          <th>Name</th>
          <th>Username</th>
          <th>User Type</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          $i = 1;
          $qry = $conn->query("SELECT *, concat(firstname,' ',lastname) as name FROM `users` WHERE id != '1' ORDER BY concat(firstname,' ',lastname) ASC ");
          while($row = $qry->fetch_assoc()):
        ?>
        <tr>
          <td><?= $i++; ?></td>
          <td><img src="<?= validate_image($row['avatar']) ?>" class="img-avatar" alt="avatar"></td>
          <td><?= ucwords($row['name']) ?></td>
          <td><?= $row['username'] ?></td>
          <td><?= ($row['type'] == 1) ? "Administrator" : "Staff" ?></td>
          <td>
            <div class="dropdown">
              <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                Action
              </button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="?page=user/manage_user&id=<?= $row['id'] ?>"><i class="fa fa-edit text-primary"></i> Edit</a>
                <?php if($row['status'] != 1): ?>
                  <a class="dropdown-item verify_user" href="javascript:void(0)" data-id="<?= $row['id'] ?>" data-name="<?= $row['username'] ?>"><i class="fa fa-check text-success"></i> Verify</a>
                <?php endif; ?>
                <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?= $row['id'] ?>"><i class="fa fa-trash text-danger"></i> Delete</a>
              </div>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  $(document).ready(function(){
    $('.delete_data').click(function(){
      _conf("Are you sure to delete this User permanently?","delete_user",[$(this).attr('data-id')])
    })
    $('.verify_user').click(function(){
      _conf("Are you sure to verify <b>"+$(this).attr('data-name')+"</b>?","verify_user",[$(this).attr('data-id')])
    })
  })

  function delete_user($id){
    start_loader();
    $.ajax({
      url:_base_url_+"classes/Users.php?f=delete",
      method:"POST",
      data:{id: $id},
      dataType:"json",
      error:err=>{
        console.log(err)
        alert_toast("An error occured.",'error');
        end_loader();
      },
      success:function(resp){
        if(typeof resp== 'object' && resp.status == 'success'){
          location.reload();
        }else{
          alert_toast("An error occured.",'error');
          end_loader();
        }
      }
    })
  }

  function verify_user($id){
    start_loader();
    $.ajax({
      url:_base_url_+"classes/Users.php?f=verify_user",
      method:"POST",
      data:{id: $id},
      dataType:"json",
      error:err=>{
        console.log(err)
        alert_toast("An error occured.",'error');
        end_loader();
      },
      success:function(resp){
        if(typeof resp== 'object' && resp.status == 'success'){
          location.reload();
        }else{
          alert_toast("An error occured.",'error');
          end_loader();
        }
      }
    })
  }
</script>
