<style>
body {
    background: #0f172a;
    font-family: 'Segoe UI', sans-serif;
    color: #f1f5f9;
}

.card.card-outline {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.08);
    backdrop-filter: blur(12px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.6);
    animation: fadeInCard 0.5s ease-in-out;
    padding: 2rem;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card.card-outline:hover {
    transform: translateY(-4px);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.8);
}

@keyframes fadeInCard {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.card-body label {
    font-weight: 600;
    font-size: 0.95rem;
    color:rgb(27, 63, 106);
    margin-bottom: 0.25rem;
}

.form-control,
.custom-select,
.custom-file-label {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 12px;
    color:rgb(18, 36, 53);
    transition: all 0.3s ease-in-out;
}

.form-control:hover,
.custom-select:hover,
.custom-file-input:hover + .custom-file-label {
    background-color: rgba(255,255,255,0.08);
    border-color: #3b82f6;
    box-shadow: 0 0 10px rgba(59, 130, 246, 0.3);
}

.form-control:focus,
.custom-select:focus {
    background: rgba(255, 255, 255, 0.08);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.4);
    border-color: #3b82f6;
    outline: none;
}

.custom-file-input:focus ~ .custom-file-label {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.4);
}

.custom-file-label::after {
    background-color: #3b82f6;
    color: #fff;
}

img#cimg {
    height: 15vh;
    width: 15vh;
    object-fit: cover;
    border-radius: 50%;
    border: 3px solid #475569;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
    transition: transform 0.3s ease;
}

img#cimg:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(59, 130, 246, 0.5);
}

.btn-primary {
    background: linear-gradient(to right, #3b82f6, #6366f1);
    border: none;
    border-radius: 30px;
    padding: 8px 24px;
    font-weight: 600;
    color: #fff;
    transition: 0.3s ease;
}

.btn-primary:hover {
    background: linear-gradient(to right, #2563eb, #4f46e5);
    transform: scale(1.03);
    box-shadow: 0 5px 15px rgba(59, 130, 246, 0.5);
}

.btn-secondary {
    border-radius: 30px;
    padding: 8px 24px;
    background: transparent;
    border: 1px solid #475569;
    color: #cbd5e1;
    transition: 0.3s ease;
}

.btn-secondary:hover {
    background: #1e293b;
    border-color: #64748b;
    color: #f8fafc;
}

.form-row {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.form-group.col-6 {
    flex: 0 0 48%;
}

.card-footer {
    background: transparent;
    border-top: 1px solid rgba(255,255,255,0.08);
    margin-top: 1.5rem;
}
</style>

<div class="card card-outline card-primary">
	<div class="card-body">
		<div class="container-fluid">
			<div id="msg"></div>
			<form action="" id="manage-user" enctype="multipart/form-data">
				<input type="hidden" name="id" value="<?php echo isset($meta['id']) ? $meta['id']: '' ?>">
				<div class="form-row">
					<div class="form-group col-6">
						<label for="firstname">First Name</label>
						<input type="text" name="firstname" id="firstname" class="form-control" value="<?php echo isset($meta['firstname']) ? $meta['firstname']: '' ?>" required>
					</div>
					<div class="form-group col-6">
						<label for="lastname">Last Name</label>
						<input type="text" name="lastname" id="lastname" class="form-control" value="<?php echo isset($meta['lastname']) ? $meta['lastname']: '' ?>" required>
					</div>
					<div class="form-group col-6">
						<label for="username">Username</label>
						<input type="text" name="username" id="username" class="form-control" value="<?php echo isset($meta['username']) ? $meta['username']: '' ?>" required autocomplete="off">
					</div>
					<div class="form-group col-6">
						<label for="password">Password</label>
						<input type="password" name="password" id="password" class="form-control" autocomplete="off" <?php echo isset($meta['id']) ? "" : "required" ?>>
						<?php if(isset($_GET['id'])): ?>
							<small class="text-info"><i>Leave this blank if you don't want to change the password.</i></small>
						<?php endif; ?>
					</div>
					<div class="form-group col-6">
						<label for="type">User Type</label>
						<select name="type" id="type" class="custom-select" required>
							<option value="1" <?= isset($meta['type']) && $meta['type'] == 1 ? 'selected' : '' ?>>Administrator</option>
							<option value="2" <?= isset($meta['type']) && $meta['type'] == 2 ? 'selected' : '' ?>>Staff</option>
						</select>
					</div>
					<div class="form-group col-6">
						<label for="customFile">Avatar</label>
						<div class="custom-file">
							<input type="file" class="custom-file-input" id="customFile" name="img" onchange="displayImg(this,$(this))">
							<label class="custom-file-label" for="customFile">Choose file</label>
						</div>
					</div>
					<div class="form-group col-6 d-flex justify-content-center">
						<img src="<?php echo validate_image(isset($meta['avatar']) ? $meta['avatar'] :'') ?>" id="cimg" class="img-fluid img-thumbnail" alt="User Avatar">
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="card-footer d-flex justify-content-end">
		<button class="btn btn-primary mr-2" form="manage-user">Save</button>
		<a href="./?page=user/list" class="btn btn-secondary">Cancel</a>
	</div>
</div>

<script>
	function displayImg(input, _this) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#cimg').attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}

	$('#manage-user').submit(function(e){
		e.preventDefault();
		var _this = $(this)
		start_loader()
		$.ajax({
			url:_base_url_+'classes/Users.php?f=save',
			data: new FormData(_this[0]),
			cache: false,
			contentType: false,
			processData: false,
			method: 'POST',
			type: 'POST',
			success:function(resp){
				if(resp == 1){
					location.href = './?page=user/list';
				} else {
					$('#msg').html('<div class="alert alert-danger">Username already exists</div>')
					$("html, body").animate({ scrollTop: 0 }, "fast");
				}
				end_loader()
			}
		})
	})
</script>
