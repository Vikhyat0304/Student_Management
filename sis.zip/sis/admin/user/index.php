<?php 
$user = $conn->query("SELECT * FROM users where id ='".$_settings->userdata('id')."'");
foreach($user->fetch_array() as $k => $v){
    $meta[$k] = $v;
}
?>
<?php if($_settings->chk_flashdata('success')): ?>
<script>
    alert_toast("<?php echo $_settings->flashdata('success') ?>", 'success')
</script>
<?php endif; ?>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
  body {
    background: linear-gradient(145deg,#1e3c72,#2a5298);
    font-family: 'Inter', sans-serif;
    padding: 40px 0;
    color: #fff;
  }

  .glass-card {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(15px);
    -webkit-backdrop-filter: blur(15px);
    border-radius: 20px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.25);
    padding: 40px;
    color: #fff;
    transition: all 0.3s ease-in-out;
  }

  .glass-card:hover {
    transform: scale(1.01);
    box-shadow: 0 12px 30px rgba(0,0,0,0.4);
  }

  .profile-heading {
    font-family: 'Poppins', sans-serif;
    font-size: 2.5rem;
    font-weight: 700;
    text-align: center;
    background: linear-gradient(90deg, #ff416c, #ff4b2b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 30px;
    text-shadow: 1px 1px 2px rgba(255,255,255,0.1);
  }

  .form-label {
    font-weight: 600;
    color:rgb(39, 51, 106);
  }

  .form-control {
    background: rgba(255, 255, 255, 0.12);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 12px 15px;
  }

  .form-control::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }

  .form-control:focus {
    box-shadow: 0 0 0 2px #fff3;
    background: rgba(255, 255, 255, 0.2);
  }

  .btn-glass {
    background: linear-gradient(to right, #00c6ff, #0072ff);
    border: none;
    padding: 12px 30px;
    border-radius: 10px;
    font-weight: 600;
    color: #fff;
    margin-top: 20px;
    transition: 0.3s ease-in-out;
  }

  .btn-glass:hover {
    background: linear-gradient(to right, #0072ff, #00c6ff);
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.2);
  }

  #cimg {
    width: 140px;
    height: 140px;
    object-fit: cover;
    border-radius: 50%;
    border: 4px solid rgba(107, 50, 50, 0.3);
    box-shadow: 0 0 15px rgba(255,255,255,0.3);
    transition: transform 0.3s ease;
  }

  #cimg:hover {
    transform: scale(1.05);
  }

  .avatar-preview {
    display: flex;
    justify-content: center;
    margin-bottom: 25px;
  }
</style>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-8 col-sm-12">
      <div class="glass-card">
        <h3 class="profile-heading">Update Your Profile</h3>
        <div id="msg"></div>
        <form action="" id="manage-user">
          <input type="hidden" name="id" value="<?php echo $_settings->userdata('id') ?>">

          <div class="mb-3">
            <label for="firstname" class="form-label">First Name</label>
            <input type="text" name="firstname" id="firstname" class="form-control"
              value="<?php echo isset($meta['firstname']) ? $meta['firstname']: '' ?>" required>
          </div>

          <div class="mb-3">
            <label for="lastname" class="form-label">Last Name</label>
            <input type="text" name="lastname" id="lastname" class="form-control"
              value="<?php echo isset($meta['lastname']) ? $meta['lastname']: '' ?>" required>
          </div>

          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control"
              value="<?php echo isset($meta['username']) ? $meta['username']: '' ?>" required>
          </div>

          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control"
              placeholder="Leave blank to keep current password">
            <small class="text-light">Leave blank if you don't want to change password.</small>
          </div>

          <div class="mb-3">
            <label for="customFile" class="form-label">Avatar</label>
            <input type="file" class="form-control" id="customFile" name="img" onchange="displayImg(this,$(this))">
          </div>

          <div class="avatar-preview">
            <img src="<?php echo validate_image(isset($meta['avatar']) ? $meta['avatar'] :'') ?>" alt="Avatar" id="cimg">
          </div>

          <div class="text-center">
            <button type="submit" class="btn btn-glass">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  function displayImg(input, _this) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#cimg').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $('#manage-user').submit(function(e){
    e.preventDefault();
    var _this = $(this);
    start_loader();
    $.ajax({
      url: _base_url_ + 'classes/Users.php?f=save',
      data: new FormData(_this[0]),
      cache: false,
      contentType: false,
      processData: false,
      method: 'POST',
      type: 'POST',
      success: function(resp){
        if(resp == 1){
          location.reload();
        } else {
          $('#msg').html('<div class="alert alert-danger">Username already exists.</div>');
          end_loader();
        }
      }
    });
  });
</script>
