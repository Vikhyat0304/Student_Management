<style>
  .img-thumb-path {
    width: 100px;
    height: 80px;
    object-fit: scale-down;
    object-position: center center;
  }

  .glass-table-card {
    background: rgba(255, 255, 255, 0.06);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 12px 28px rgba(0,0,0,0.15);
    transition: all 0.3s ease;
  }

  .glass-table-card:hover {
    transform: scale(1.01);
    box-shadow: 0 18px 34px rgba(0,0,0,0.2);
  }

  .glass-table-card .card-title {
    font-size: 1.4rem;
    font-weight: 600;
    color: #222;
  }

  .table thead {
    background: linear-gradient(to right, #007bff, #00c6ff);
    color: #fff;
  }

  .table tbody tr {
    transition: all 0.2s ease-in-out;
  }

  .table tbody tr:hover {
    background: rgba(0, 0, 0, 0.02);
    transform: scale(1.01);
  }

  .badge-status {
    padding: 6px 14px;
    font-size: 0.75rem;
    border-radius: 50px;
    font-weight: 500;
  }

  .badge-active {
    background: linear-gradient(to right, #28a745, #3edb7b);
    color: #fff;
  }

  .badge-inactive {
    background: linear-gradient(to right, #dc3545, #ff5e62);
    color: #fff;
  }

  .btn-view {
    font-size: 0.75rem;
    border-radius: 30px;
    padding: 5px 12px;
    transition: 0.2s;
  }

  .btn-view:hover {
    background: #007bff;
    color: #fff;
  }

  .btn-add {
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 500;
    padding: 8px 16px;
    background: linear-gradient(to right, #00b4db, #0083b0);
    color: white;
    transition: all 0.2s ease;
  }

  .btn-add:hover {
    background: linear-gradient(to right, #0083b0, #00b4db);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  }
</style>

<div class="glass-table-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="card-title m-0">📋 Student Directory</h3>
    <a href="./?page=students/manage_student" class="btn btn-add">
      <i class="fas fa-plus me-1"></i> Add New Student
    </a>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered table-hover text-center align-middle mb-0">
      <thead>
        <tr>
          <th>#</th>
          <th>Date Created</th>
          <th>Roll No.</th>
          <th>Name</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          $i = 1;
          $qry = $conn->query("SELECT *, CONCAT(lastname, ', ', firstname, ' ', middlename) as fullname FROM `student_list` ORDER BY fullname ASC");
          while($row = $qry->fetch_assoc()):
        ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= date("Y-m-d H:i", strtotime($row['date_created'])) ?></td>
          <td><?= $row['roll'] ?></td>
          <td><?= $row['fullname'] ?></td>
          <td>
            <?php 
              echo $row['status'] == 1 
              ? '<span class="badge badge-status badge-active">Active</span>' 
              : '<span class="badge badge-status badge-inactive">Inactive</span>';
            ?>
          </td>
          <td>
            <a href="./?page=students/view_student&id=<?= $row['id'] ?>" class="btn btn-outline-secondary btn-view">
              <i class="fa fa-eye me-1"></i> View
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  $(document).ready(function () {
    $('.table').DataTable({
      columnDefs: [{ orderable: false, targets: 5 }],
      pageLength: 10
    });
  });

  function delete_student(id) {
    start_loader();
    $.ajax({
      url: _base_url_ + "classes/Master.php?f=delete_student",
      method: "POST",
      data: { id: id },
      dataType: "json",
      error: err => {
        console.log(err);
        alert_toast("An error occurred.", 'error');
        end_loader();
      },
      success: function (resp) {
        if (typeof resp === 'object' && resp.status === 'success') {
          location.reload();
        } else {
          alert_toast("An error occurred.", 'error');
          end_loader();
        }
      }
    });
  }
</script>
