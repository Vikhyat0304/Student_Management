<?php
$id = null;
if (isset($_GET['id'])) {
    $qry = $conn->query("SELECT *, CONCAT(lastname,', ', firstname,' ', middlename) as fullname FROM `student_list` WHERE id = '{$_GET['id']}'");
    if ($qry && $qry->num_rows > 0) {
        $res = $qry->fetch_array();
        foreach ($res as $k => $v) {
            if (!is_numeric($k)) $$k = $v;
        }
        $id = $_GET['id'];
    } else {
        echo "<div class='alert alert-danger p-2'>Student record not found.</div>";
        exit;
    }
} else {
    echo "<div class='alert alert-warning p-2'>Student ID missing.</div>";
    exit;
}
?>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e1e2f, #3e3e5e);
        font-family: 'Poppins', sans-serif;
        color: #fff;
    }

    .glass-card {
        background: rgba(255, 255, 255, 0.06);
        backdrop-filter: blur(14px);
        border-radius: 20px;
        box-shadow: 0 15px 45px rgba(0, 0, 0, 0.4);
        padding: 30px;
        color:rgb(57, 25, 25);
    }

    .glass-card:hover {
        transform: scale(1.01);
        transition: all 0.3s ease-in-out;
    }

    .card-title {
        font-size: 1.7rem;
        font-weight: 700;
        background: linear-gradient(90deg,rgb(96, 75, 46), #fcb69f);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 20px;
    }

    label {
        font-weight: 600;
        color:rgb(84, 41, 41);
    }

    .info-text {
        font-weight: 500;
        font-size: 1rem;
        color:rgb(61, 28, 28);
    }

    legend {
        color:rgb(83, 34, 33);
        border-bottom: 1px solid #666;
        padding-bottom: 5px;
        margin-top: 20px;
        font-weight: 600;
    }

    .badge {
        font-size: 0.9rem;
        padding: 6px 12px;
        border-radius: 1rem;
    }

    .table-striped tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.05);
    }

    .btn {
        font-weight: 600;
    }

    .thead-dark th {
        background-color: #343a40;
        color: #fff;
    }

    .table td, .table th {
        color: #fff;
    }

      /* Academic Table Visibility Fix */
    #academic-history {
        background-color: rgba(30, 30, 30, 0.75);
        border-radius: 12px;
        overflow: hidden;
        color: #fff;
        font-size: 0.95rem;
    }

    #academic-history thead {
        background-color: rgba(0, 0, 0, 0.5);
        color: #f8f9fa;
    }

    #academic-history thead th {
        padding: 12px 10px;
        font-weight: 600;
        border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    #academic-history tbody tr {
        background-color: rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease-in-out;
    }

    #academic-history tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }

    #academic-history td {
        color: #f1f1f1;
        padding: 10px 8px;
        vertical-align: middle;
        border-top: 1px solid rgba(255,255,255,0.1);
    }

    /* Buttons inside table */
    #academic-history .btn {
        font-size: 0.75rem;
        padding: 4px 10px;
        border-radius: 8px;
        transition: 0.3s ease;
    }

    .btn-outline-primary:hover {
        background-color: rgba(102, 126, 234, 0.2);
        color: #fff;
    }

    .btn-outline-danger:hover {
        background-color: rgba(255, 99, 132, 0.2);
        color: #fff;
    }

    /* Stylish Buttons */
    .btn-gradient {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: #fff !important;
        border: none;
        border-radius: 10px;
        padding: 6px 14px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #764ba2, #667eea);
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.3);
    }

    .btn-outline-light {
        border: 1px solid #ccc;
        color: #eee;
        background-color: transparent;
    }

    .btn-outline-light:hover {
        background-color: rgba(255,255,255,0.15);
        color: #fff;
    }

</style>


<div class="content py-4">
    <div class="glass-card">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h5 class="card-title mb-0">Student Details</h5>
            <div>
              <div class="btn-group">
    <a class="btn btn-sm btn-gradient" href="./?page=students/manage_student&id=<?= $id ?>"><i class="fa fa-edit"></i> Edit</a>
    <button class="btn btn-sm btn-gradient" id="delete_student"><i class="fa fa-trash"></i> Delete</button>
    <button class="btn btn-sm btn-gradient" id="add_academic"><i class="fa fa-plus"></i> Add Academic</button>
    <button class="btn btn-sm btn-gradient" id="update_status"><i class="fa fa-refresh"></i> Update Status</button>
    <button class="btn btn-sm btn-gradient" id="print"><i class="fa fa-print"></i> Print</button>
    <a href="./?page=students" class="btn btn-sm btn-outline-light"><i class="fa fa-angle-left"></i> Back</a>
</div>

            </div>
        </div>
        <div id="outprint">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>Student Roll</label>
                    <div class="info-text"><?= $roll ?? 'N/A' ?></div>
                </div>
                <div class="col-md-6">
                    <label>Status</label>
                    <div>
                        <?= ($status ?? 0) == 1 ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?>
                    </div>
                </div>
            </div>

            <fieldset>
                <legend>Personal Info</legend>
                <div class="row">
                    <div class="col-md-4">
                        <label>Name</label>
                        <div class="info-text"><?= $fullname ?? 'N/A' ?></div>
                    </div>
                    <div class="col-md-4">
                        <label>Gender</label>
                        <div class="info-text"><?= $gender ?? 'N/A' ?></div>
                    </div>
                    <div class="col-md-4">
                        <label>Date of Birth</label>
                        <div class="info-text"><?= isset($dob) ? date("M d, Y", strtotime($dob)) : 'N/A' ?></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Present Address</label>
                        <div class="info-text"><?= $present_address ?? 'N/A' ?></div>
                    </div>
                    <div class="col-md-6">
                        <label>Permanent Address</label>
                        <div class="info-text"><?= $permanent_address ?? 'N/A' ?></div>
                    </div>
                </div>
            </fieldset>

            <fieldset>
                <legend>Academic History</legend>
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Department/Course</th>
                            <th>Semester/Year</th>
                            <th>Year</th>
                            <th>Start Status</th>
                            <th>End Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $academics = $conn->query("SELECT a.*, c.name as course, d.name as department FROM academic_history a JOIN course_list c ON a.course_id = c.id JOIN department_list d ON c.department_id = d.id WHERE a.student_id = '{$id}' ORDER BY a.school_year ASC");
                        while ($row = $academics->fetch_assoc()):
                        ?>
                            <tr>
                                <td><?= $i++ ?></td>
                                <td><?= $row['department'] . '<br>' . $row['course'] ?></td>
                                <td><?= $row['semester'] . '<br>' . $row['school_year'] ?></td>
                                <td><?= $row['year'] ?></td>
                                <td><?= ['New', 'Regular', 'Returnee', 'Transferee'][$row['status'] - 1] ?? 'N/A' ?></td>
                                <td><?= ['Pending', 'Completed', 'Dropout', 'Failed', 'Transferred Out', 'Graduated'][$row['end_status']] ?? 'N/A' ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary edit_academic" data-id="<?= $row['id'] ?>">Edit</button>
                                    <button class="btn btn-sm btn-outline-danger delete_academic" data-id="<?= $row['id'] ?>">Delete</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </fieldset>
        </div>
    </div>
</div>
