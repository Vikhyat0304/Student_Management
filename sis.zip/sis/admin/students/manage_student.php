<!-- Fonts & Bootstrap -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body {
        background: linear-gradient(to right, #4b6cb7, #182848);
        font-family: 'Poppins', sans-serif;
        padding: 30px;
    }

    .glass-form-card {
        background: rgba(255, 255, 255, 0.95); /* solid white with slight transparency */
        border-radius: 15px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
        padding: 30px;
        color: #222;
        transition: 0.3s ease;
    }

    .glass-form-card:hover {
        box-shadow: 0 16px 45px rgba(0, 0, 0, 0.35);
    }

    .glass-form-card h3 {
        font-size: 1.8rem;
        font-weight: 700;
        text-align: center;
        margin-bottom: 25px;
        color: #333;
    }

    .form-label {
        color: #222;
        font-weight: 600;
    }

    .form-control {
        border-radius: 10px;
        border: 1px solid #ccc;
        background: #fff;
        color: #000;
    }

    .form-control::placeholder {
        color: #666;
    }

    textarea.form-control {
        resize: none;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #667eea, #764ba2);
        border: none;
        color: white;
        font-weight: 600;
        border-radius: 10px;
        padding: 10px 25px;
        transition: 0.3s ease-in-out;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #764ba2, #667eea);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="glass-form-card">
                <h3><?= isset($id) ? "Update Student - " . $roll : "New Student Registration" ?></h3>
                <form action="" id="student_form">
                    <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="roll" class="form-label">Roll Number</label>
                            <input type="text" name="roll" id="roll" value="<?= $roll ?? '' ?>" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label for="firstname" class="form-label">First Name</label>
                            <input type="text" name="firstname" id="firstname" value="<?= $firstname ?? '' ?>" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label for="lastname" class="form-label">Last Name</label>
                            <input type="text" name="lastname" id="lastname" value="<?= $lastname ?? '' ?>" class="form-control" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="middlename" class="form-label">Middle Name</label>
                            <input type="text" name="middlename" id="middlename" value="<?= $middlename ?? '' ?>" class="form-control" placeholder="Optional">
                        </div>
                        <div class="col-md-4">
                            <label for="gender" class="form-label">Gender</label>
                            <select name="gender" id="gender" class="form-control" required>
                                <option value="Male" <?= ($gender ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= ($gender ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="dob" class="form-label">Date of Birth</label>
                            <input type="date" name="dob" id="dob" value="<?= $dob ?? '' ?>" class="form-control" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="contact" class="form-label">Contact</label>
                            <input type="text" name="contact" id="contact" value="<?= $contact ?? '' ?>" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="present_address" class="form-label">Present Address</label>
                            <textarea name="present_address" id="present_address" rows="2" class="form-control" required><?= $present_address ?? '' ?></textarea>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="permanent_address" class="form-label">Permanent Address</label>
                        <textarea name="permanent_address" id="permanent_address" rows="2" class="form-control" required><?= $permanent_address ?? '' ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-gradient">Save Student Details</button>
                        <a href="./?page=students" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $('#student_form').submit(function(e){
        e.preventDefault();
        var _this = $(this);
        start_loader();
        $.ajax({
            url: _base_url_ + "classes/Master.php?f=save_student",
            data: new FormData(_this[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            dataType: 'json',
            success: function(resp){
                if(resp.status == 'success'){
                    location.href = "./?page=students/view_student&id=" + resp.sid;
                } else {
                    alert_toast(resp.msg || "An unexpected error occurred", 'error');
                }
                end_loader();
            },
            error: err => {
                console.error(err);
                alert_toast("An error occurred", 'error');
                end_loader();
            }
        });
    });
</script>
