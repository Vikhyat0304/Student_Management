<style>
    .form-section {
        background: #fdfdfd;
        border: 1px solid #e2e8f0;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 20px;
        box-shadow: 0 6px 12px rgba(0,0,0,0.05);
    }
    .form-section h5 {
        font-weight: 600;
        font-size: 1.1rem;
        margin-bottom: 1rem;
        border-left: 4px solid #007bff;
        padding-left: 12px;
        color: #333;
    }
    .form-control {
        border-radius: 6px !important;
        font-size: 0.9rem;
    }
    label {
        font-weight: 500;
        margin-bottom: 4px;
    }
</style>

<div class="container-fluid">
    <form action="" id="academic-form">
        <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">
        <input type="hidden" name="student_id" value="<?= isset($_GET['student_id']) ? $_GET['student_id'] : '' ?>">

        <!-- Academic Term -->
        <div class="form-section">
            <h5>Academic Term Info</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="semester" class="form-label">Semester</label>
                    <select name="semester" id="semester" class="form-select" required>
                        <option <?= !isset($semester) || $semester == 'First Semester' ? 'selected' : '' ?>>First Semester</option>
                        <option <?= (isset($semester) && $semester == 'Second Semester') ? 'selected' : '' ?>>Second Semester</option>
                        <option <?= (isset($semester) && $semester == 'Third Semester') ? 'selected' : '' ?>>Third Semester</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="school_year" class="form-label">School Year</label>
                    <input type="text" name="school_year" id="school_year" value="<?= $school_year ?? '' ?>" class="form-control" placeholder="e.g. 2024-25" required>
                </div>
            </div>
        </div>

        <!-- Course & Year -->
        <div class="form-section">
            <h5>Course Details</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="course_id" class="form-label">Course</label>
                    <select name="course_id" id="course_id" class="form-select select2" required>
                        <option <?= !isset($course_id) ? 'selected' : '' ?> disabled>Please select</option>
                        <?php 
                            $courses = $conn->query("SELECT c.*, d.name as department FROM `course_list` c INNER JOIN `department_list` d ON c.department_id = d.id WHERE c.delete_flag = 0 AND c.status = 1 ".(isset($course_id) ? " OR c.id = '{$course_id}' " : "")." ORDER BY d.name ASC, c.name ASC ");
                            while($row = $courses->fetch_assoc()):
                        ?>
                        <option value="<?= $row['id'] ?>" <?= isset($course_id) && $course_id == $row['id'] ? 'selected' : '' ?>>
                            <?= $row['department'] . " - " . $row['name'] ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="year" class="form-label">Year</label>
                    <input type="text" name="year" id="year" value="<?= $year ?? '' ?>" class="form-control" placeholder="e.g. 2nd Year" required>
                </div>
            </div>
        </div>

        <!-- Status Info -->
        <div class="form-section">
            <h5>Status Info</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="status" class="form-label">Beginning of Semester Status</label>
                    <select name="status" id="status" class="form-select" required>
                        <option value="1" <?= (isset($status) && $status == 1) ? 'selected' : '' ?>>New</option>
                        <option value="2" <?= (isset($status) && $status == 2) ? 'selected' : '' ?>>Regular</option>
                        <option value="3" <?= (isset($status) && $status == 3) ? 'selected' : '' ?>>Returnee</option>
                        <option value="4" <?= (isset($status) && $status == 4) ? 'selected' : '' ?>>Transferee</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="end_status" class="form-label">End of Semester Status</label>
                    <select name="end_status" id="end_status" class="form-select" required>
                        <option value="0" <?= (isset($end_status) && $end_status == 0) ? 'selected' : '' ?>>Pending</option>
                        <option value="1" <?= (isset($end_status) && $end_status == 1) ? 'selected' : '' ?>>Completed</option>
                        <option value="2" <?= (isset($end_status) && $end_status == 2) ? 'selected' : '' ?>>Dropout</option>
                        <option value="3" <?= (isset($end_status) && $end_status == 3) ? 'selected' : '' ?>>Failed</option>
                        <option value="4" <?= (isset($end_status) && $end_status == 4) ? 'selected' : '' ?>>Transferred Out</option>
                        <option value="5" <?= (isset($end_status) && $end_status == 5) ? 'selected' : '' ?>>Graduated</option>
                    </select>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
  $(function(){
    $('#uni_modal').on('shown.bs.modal', function(){
        $('#course_id').select2({
            placeholder: 'Please Select Here',
            width: "100%",
            dropdownParent: $('#uni_modal')
        });
    });

    $('#academic-form').submit(function(e){
        e.preventDefault();
        var _this = $(this);
        if (_this[0].checkValidity() === false) {
            _this[0].reportValidity();
            return false;
        }
        $('.pop-msg').remove();
        var el = $('<div>').addClass("pop-msg alert").hide();
        start_loader();

        $.ajax({
            url: _base_url_ + "classes/Master.php?f=save_academic",
            data: new FormData(_this[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            dataType: 'json',
            error: err => {
                console.log(err);
                alert_toast("An error occurred", 'error');
                end_loader();
            },
            success: function(resp) {
                if (resp.status == 'success') {
                    location.reload();
                } else {
                    el.addClass("alert-danger").text(resp.msg || "An unknown error occurred.");
                    _this.prepend(el);
                    el.show('slow');
                    $('html,body,.modal').animate({ scrollTop: 0 }, 'fast');
                    end_loader();
                }
            }
        });
    });
  });
</script>
